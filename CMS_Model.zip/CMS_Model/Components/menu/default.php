<?php

// echo 'OI';

// buscar lista do bd
$menuItems = [
    'Home' => '/home',
    'Stores' => '/stores',
];

// echo '<pre>'; print_r($menuItems);

/* 
echo "<pre>";
print_r($menu); */

return $menuItems;